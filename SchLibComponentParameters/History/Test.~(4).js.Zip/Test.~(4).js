//..............................................................................
// Summary A simple hello world - an introduction to JScript language.
// Copyright (c) 2003 by Altium Limited
//..............................................................................

//..............................................................................
function Main(){
    ShowMessage("Hello world! How are you?");
}

